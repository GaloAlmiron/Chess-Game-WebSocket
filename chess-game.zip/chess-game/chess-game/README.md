# Chess Game

# Juego de Ajedrez en Tiempo Real

Un juego de ajedrez en línea que utiliza WebSocket, JavaScript y Node.js junto con las bibliotecas `chess.js`(para la lógica del juego) y `Chessboard.js` (la interfaz de usuario del ajedrez.)
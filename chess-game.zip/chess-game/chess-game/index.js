require('dotenv').config();
const path = require('path');
require(path.join(__dirname, 'server', 'server.js'));